/**
 * @license Highstock JS v9.3.2 (2021-11-29)
 * @module highcharts/modules/heikinashi
 * @requires highcharts
 * @requires highcharts/modules/stock
 *
 * HeikinAshi series type for Highcharts Stock
 *
 * (c) 2010-2021 Karol Kolodziej
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/HeikinAshi/HeikinAshiSeries.js';
