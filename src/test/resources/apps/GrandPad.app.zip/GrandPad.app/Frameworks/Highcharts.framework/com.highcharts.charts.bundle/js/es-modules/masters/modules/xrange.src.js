/**
 * @license Highcharts JS v9.3.2 (2021-11-29)
 * @module highcharts/modules/xrange
 * @requires highcharts
 *
 * X-range series
 *
 * (c) 2010-2021 Torstein Honsi, Lars A. V. Cabrera
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/XRange/XRangeSeries.js';
